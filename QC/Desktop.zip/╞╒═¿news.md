# Title

🚛 启承国际参加中国龍盛俱乐部沃尔沃卡车节 | 2024.9.16



# Summary

2024年9月16日启承国际参加中国龍盛俱乐部沃尔沃卡车节



# Content

# ![中文](https://pic.imgdb.cn/item/66c1c641d9c307b7e9fde7de.png)中文
### 时间：2024年9月16日
### 起点：格拉斯哥
### 终点：多佛
### 公里数：819km
### 集合时间：19:00（UTC+8）
### 出发时间：20:30（UTC+8）
### 服务器：CN LS September Public Event

-----


# ![英文](https://pic.imgdb.cn/item/66c1c641d9c307b7e9fde7c4.png)English
### Date : Sep 15, 2024
### Starting Point : Glasgow
### Destination : Dover
### Kilometers: 819km
### Meeting time : 19:00 (UTC+8)
### Departure time : 20:30 (UTC+8)
### Server : CN LS September Public Event



**[![link](https://pic.imgdb.cn/item/66e04d5dd9c307b7e95cea68.png)Click on Me to view the event page](https://truckersmp.com/events/23406)**

---

![启承国际联运图片](https://pic.imgdb.cn/item/66e83221d9c307b7e981ce0c.jpg)

![启承国际联运图片](https://pic.imgdb.cn/item/66e83222d9c307b7e981ce5b.jpg)

![启承国际联运图片](https://pic.imgdb.cn/item/66e83222d9c307b7e981ce93.jpg)

---
# ![联系我们](https://pic.imgdb.cn/item/66c1c641d9c307b7e9fde7a8.png)联系我们
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;[![联系我们QQ](https://pic.imgdb.cn/item/66c1c734d9c307b7e900037c.png)](https://qm.qq.com/q/xZkrjf0lKS) &ensp;&ensp;&ensp;[![联系我们YY](https://pic.imgdb.cn/item/66c1c735d9c307b7e90003f3.png)](https://z.yy.com/17aoTYZYvC34) &ensp;&ensp;&ensp; [![联系我们DC](https://pic.imgdb.cn/item/66c1c735d9c307b7e9000416.png)](https://discord.gg/9azFthjbTZ)

Copyright © 2024 Qicheng International. All rights reserved.